<?php   
     require_once 'controladores/Controlador.php';
     $controlador = new Controlador();
     $controlador->run();
     ?>

     