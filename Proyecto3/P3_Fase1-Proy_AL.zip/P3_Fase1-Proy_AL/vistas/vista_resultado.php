<?php
      include "cabecera.php";
      
      echo "<div class='texto' />";
      echo $resultado;
      echo "</div>";
      
      include "pie.php";
?>
