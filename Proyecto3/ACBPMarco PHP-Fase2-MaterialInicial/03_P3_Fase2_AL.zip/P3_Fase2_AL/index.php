<?php
require_once 'config/config.php';
$controlador = new Controlador();
$controlador->run();
?>

