<?php

/*
 * No lo utilizamos en el primer ejemplo de validación
 */

class Utilidades
{

    public static function verArray($array)
    {
        echo "<pre>";
        print_r($array);
        echo "</pre>";
    }

}
